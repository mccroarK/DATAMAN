# Math Functions

def add(x, y):
    """Addition Function"""
    return x + y
    
def sub(x, y):
    """Subtraction Function"""
    return x - y
    
def div(x, y):
    """Division Function"""
    return x / y
    
def mul(x, y):
    """Multiplication Function"""
    return x * y
    
def mod(x, y):
    """Modulus Function"""
    return x % y

# TEMP: replace in Question object
def ans(x, y, op):
    """Answer using the operation symbol to choose equation"""
    result = 0 # Initialize result variable
    
    # Try
    try:
        # convert inputs to floats
        x = float(x)
        y = float(y)
        
        if op == "+":
            # Operation is addition
            result = add(x, y)
        elif op == "-":
            # Operation is subtraction
            result = sub(x, y)
        elif op == "/":
            # Operation is division
            result = div(x, y)
        elif op == "*":
            # Operation is multiplication
            result = mul(x, y)
        else:
            # Operation is modulus
            result = div(x, y)
            
    # Error: Dividing by Zero
    except ZeroDivisionError:
        # Answer equals an error
        result = "Bad Input"
        
    # Error: Input is not numerical
    except ValueError:
        # answer equals an error
        result = "Bad Input"
        
    # Return the result
    return result