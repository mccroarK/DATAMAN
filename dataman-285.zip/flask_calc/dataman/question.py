class Question:
    def __init__(self, input1, input2, operation):
        self.input1 = input1
        self.input2 = input2
        self.operation = operation
        self.result = None