# Import packages
from flask import Blueprint, request, render_template
from . import calc, question

# Create the blueprint
bp = Blueprint('math', __name__, url_prefix='/math')

@bp.route('/calculator', methods=['GET', 'POST'])
def calculator():
    # When user inputs information (GET)
    if request.method == 'GET':
        # Display form to input math equation
        return render_template('math/calculator.html')
    
    # When user received the information (POST)
    else:
        # Set error and result to none
        error = None
        result = None
        
        # Create question object using user input
        ques = question.Question(request.form['Input1'],
                        request.form['Input2'],
                        request.form['operation'])
        
        # Answer the question
        ques.result = calc.ans(ques.input1, ques.input2, ques.operation)
        
        # Store the answer in a database
        
        
        # Return the form with values
        return render_template(
            'math/calculator.html',
            input1 = ques.input1,
            input2 = ques.input2,
            operation = ques.operation,
            result = ques.result,
            calculation_success=True
            )