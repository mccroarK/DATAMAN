from flask import Flask, render_template

# Create the app
app = Flask(__name__)

# Register the math blueprint
from . import math
app.register_blueprint(math.bp)

# Index page
@app.route('/')
def index():
    """ Index page """
    return 'index page'
    
# Test extend page
@app.route('/help')
def help():
    """ Test page"""
    return render_template('math/calculator.html')