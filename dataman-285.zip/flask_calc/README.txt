Create a math python file to store blueprints for the math section of the site
Create an auth python file to store blueprints for the authentication section of the site