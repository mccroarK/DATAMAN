from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/', methods=['GET'])
def index():
    """ Displays the index page at '/' """
    
    return render_template('index.html')
    
@app.route('/calc_result/', methods=['POST'])
def calc_result():
    """ Displays the calculator result using form input """
    
    # Inputs from index form (match with "name=")
    input_1 = request.form['Input1']
    input_2 = request.form['Input2']
    operation = request.form['operation']
    
    return render_template('index.html')