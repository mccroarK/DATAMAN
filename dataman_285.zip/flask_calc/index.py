from flask import Flask, render_template

app = Flask(__name__)


@app.route('/')
def index():
    """ The home page / index page """
    
    return render_template('basic_page.html') # The index page template


@app.route('/register')
def register():
    """ The register page for a user """
    
    return # The register page template


@app.route('/login')
def login():
    """ The login page for a user """
    
    return # The login page template

    
@app.route('/calc')
def calculator():
    """ The calculator page """
    
    return render_template('basic_page.html') # The calculator page template