# Import packages
from flask import Blueprint, request, render_template
from objects import test_object

# Create the blueprint
bp = Blueprint('test', __name__, url_prefix='/test')

# Test index page
@bp.route('/')
def test_page():
    garb = test_object.TestOb(1)
    return str(garb.input1)