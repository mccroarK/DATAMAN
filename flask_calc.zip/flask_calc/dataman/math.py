# Import packages
from flask import Blueprint, request, render_template
import random

# Created modules
from objects.question import Question
from logic import calc

# Create the blueprint
bp = Blueprint('math', __name__, url_prefix='/math')

# Answer Checker (/math/check)
@bp.route('/check', methods=['GET', 'POST'])
def answer_checker():
    """ Create a random question that the user has to answer """
    # If form request method is GET
    if request.method == 'GET':
        # Create random inputs and an answer (TODO GET VALUES FROM 'POST' METHOD)
        rand_value1 = random.randint(1, 20)
        rand_value2 = random.randint(1, 20)
        rand_operation = random.choice(calc.operations)
        
        # Assign the question variable to a Question object
        ques = Question(rand_value1, rand_value2, rand_operation)
        
        # Answer the Question
        ques.answer = calc.ans(ques.value1, ques.value2, ques.operation)
        
        # Display check page
        return render_template(
            'math/check/input.html',
            value1 = ques.value1,
            value2 = ques.value2,
            ans = ques.answer,
            operation = ques.operation)
    
    # If form request method is POST
    else:
        # Create correct variable
        user_correct = False
        
        # Store user GET answer
        saved_value1 = request.form['Value1']
        saved_value2 = request.form['Value2']
        saved_ans = request.form['Ans']
        saved_operation = request.form['Operation']
        saved_input = request.form['Input1']
        
        # Check if player is correct
        user_correct = calc.compare(saved_ans, saved_input)
            
        # Display answer page
        return render_template(
            'math/check/answer.html',
            input1 = saved_input,
            value1 = saved_value1,
            value2 = saved_value2,
            operation = saved_operation,
            ans = saved_ans,
            correct = user_correct)
    
# Number Guesser (/math/guess)
@bp.route('/guess', methods=['GET', 'POST'])
def number_guesser():
    if request.method == 'GET':
        # Create a random range and answer (TODO GET VALUES FROM 'POST' METHOD)
        range_min = 0
        range_max = random.randint(1, 100)
        range_ans = random.randint(range_min, range_max)
        
        # Display guess page (Answer)
        return render_template(
            'math/guess/input.html',
            min_value = range_min,
            max_value = range_max,
            ans = range_ans)
    else:
        # Create correct variable
        user_correct = False
        
        # Store user GET answer
        saved_ans = request.form['Ans']
        saved_input = request.form["Input1"]
        
        # Check if player is correct
        user_correct = calc.compare(saved_ans, saved_input)
        
        # Display guess page (Answer)
        return render_template(
            'math/guess/answer.html',
            ans = saved_ans,
            input1 = saved_input,
            correct = user_correct)