# Math Functions
operations = ['+','-','/','*','%']

def add(x, y):
    """Addition Function"""
    return x + y
    
def sub(x, y):
    """Subtraction Function"""
    return x - y
    
def div(x, y):
    """Division Function"""
    return x / y
    
def mul(x, y):
    """Multiplication Function"""
    return x * y
    
def mod(x, y):
    """Modulus Function"""
    return x % y

def compare(x, y):
    """Compare two numbers"""
    boolean = False
    
    try:
        # Convert inputs to floats
        x = float(x)
        y = float(y)
        
        # Check if numbers match
        if (x == y):
            # Match is true
            boolean = True
        else:
            # Match is false
            boolean = False
    
    # Error: Input is not numerical
    except ValueError:
        # Match is false
        boolean = False
    
    # Return boolean
    return boolean
    
# TEMP: replace in Question object
def ans(x, y, op):
    """Answer using the operation symbol to choose equation"""
    result = 0 # Initialize result variable
    
    # Try
    try:
        # convert inputs to floats
        x = float(x)
        y = float(y)
        
        if op == operations[0]:
            # Operation is addition
            result = add(x, y)
        elif op == operations[1]:
            # Operation is subtraction
            result = sub(x, y)
        elif op == operations[2]:
            # Operation is division
            result = div(x, y)
        elif op == operations[3]:
            # Operation is multiplication
            result = mul(x, y)
        else:
            # Operation is modulus
            result = div(x, y)
            
    # Error: Dividing by Zero
    except ZeroDivisionError:
        # Answer equals an error
        result = "Bad Input"
        
    # Error: Input is not numerical
    except ValueError:
        # answer equals an error
        result = "Bad Input"
        
    # Return the result
    return result