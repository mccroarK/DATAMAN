class TestOb:
    def __init__(self, input1):
        self.input1 = input1