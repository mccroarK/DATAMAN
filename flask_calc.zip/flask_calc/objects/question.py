class Question:
    def __init__(self, value1, value2, operation):
        self.value1 = value1
        self.value2 = value2
        self.operation = operation
        self.answer = None